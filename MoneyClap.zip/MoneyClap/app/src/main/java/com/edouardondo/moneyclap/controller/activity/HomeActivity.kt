package com.edouardondo.moneyclap.controller.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.edouardondo.moneyclap.R

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
    }
}